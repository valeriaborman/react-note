

function Footer() {
    return (
      <div>
        <footer className="page-footer font-small navbar-dark bg-dark ">
                <div className="container navbar-nav">
                    <div className="footer-copyright text-center py-3">
                        <a className="nav-link" href="https://mdbootstrap.com/"> 2024 Valeria Borman</a>
                    </div>
                </div>
            </footer>
      </div>
    );
  }
  
  export default Footer;
  