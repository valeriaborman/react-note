function Error() {
    return (
      <div>
            <div class="p-3 mb-2 bg-primary text-white mt-3 text-center">404 there is no such page</div>
      </div>
    );
  }
  
  export default Error;
  